//TBSI-SSR LinZenan
//板载ICM42605 6轴模组, 外置JY901 9轴模组
//修改于2022年09月07日，此程序供tactile sensing数据采集项目使用-加入了自动识别IMU传感器功能，一套固件完成多版本兼容
//修改于2022年09月06日，此程序供tactile sensing数据采集项目使用-使用UDP发送到主机中，加入了freertos任务调度功能，暂时去掉了在线升级功能以及蓝牙透传功能
#include <Arduino.h>

//WIFI UDP相关
#include <WiFi.h>
#include <AsyncUDP.h>
AsyncUDP udp;

//传感器相关
#include "ICM42605.h"
#include "QMI8658C.h"
#include "I2Cdev.h"
#include "JY901.h"

//四元数&欧拉角计算
#include "SensorFusion.h" //SF
SF fusion;

// 欧拉角计算相关参数定义
float o_gx, o_gy, o_gz, o_ax, o_ay, o_az, o_mx, o_my, o_mz;
float pitch, roll, yaw;
float cal_q[4];
float deltat;
//角度到弧度转换
float pi = 3.141592653589793238462643383279502884f;

#define I2C_BUS          Wire                           // Define the I2C bus (Wire instance) you wish to use
I2Cdev                   i2c_0(&I2C_BUS);               // Instantiate the I2Cdev object and point to the desired I2C bus
ICM42605 ICM42605(&i2c_0); // instantiate ICM42605 class
QMI8658C QMI8658C(&i2c_0); // instantiate QMI8658C class

int sensor_index = 0; //用于扫描IIC时候判定，0--unknown 1--ICM42605 2--QMI8658C

// IIC端口号
// #define SDA0 22
// #define SCL0 21
#define SDA0 15
#define SCL0 4

// LED端口号
#define myLed_R 32
#define ad0 13 //set to high for QMI8658C
// #define myLed_G 18
// #define myLed_B 5
static bool led_status = true;

// // 模拟开关
// #define DC1 13
// #define DC2 15

#define SerialDebug false  // set to true to get Serial output for debugging

// WIFI配置相关
const char* ssid = "1111C_2.4G";
const char* password = "ssrgroup";
char To_IP[] = "10.168.1.127";
// const char* ssid = "TBSI-SSR-Zenan";
// const char* password = "cn1234567890";

// 获取网络时间相关(本来考虑使用网络时间同步，但是发现单位只能到 s)
const char *ntpServer = "pool.ntp.org";
const long gmtOffset_sec = 8 * 3600;
const int daylightOffset_sec = 0;

int time_from = 2; // 1--从网络时间获取-s，2--从系统时钟获取-ms

// adc port*4
const int potPin_01 = 39; // TENG1检测
const int potPin_02 = 32; // TENG2检测
const int potPin_03 = 33; // res1检测
const int potPin_04 = 34; // res2检测
const int potPin_05 = 35; // 电池电压检测

// some parameters 
unsigned char DataToSend[30];//send to ANOV7

// 定义采集数据包-结构体
typedef struct {
  int16_t data_imu_onboard[7];//on board imu raw data
  int16_t data_imu_exboard[10];//out of board imu raw data
  int16_t data_adc[5];//raw data 0~4095
  int16_t time_record[4]; // tm_sec | tm_min | tm_hour | tm_mday
  int time_sys; // 系统时钟
} Datapack;

// 定义采集数据包-结构体
typedef struct {
  float data_imu_onboard[7];//on board imu raw data  [accx, accy, accz, gyrox, gyroy, gyroz, temp]
  int16_t time_record[4]; // tm_sec | tm_min | tm_hour | tm_mday
  int time_sys; // 系统时钟
} Datapack_collect;

// 定义发送数据包-结构体
typedef struct {
  int16_t data_imu_onboard[7];//on board imu raw data
  int16_t onboard_euler_angle[3]; // roll pitch yaw * 100
  int16_t onboard_qu_value[4]; // q0~q3 * 10000
  int16_t time_record[4]; // tm_sec | tm_min | tm_hour | tm_mday
  int time_sys; // 系统时钟
} Datapack_send;

Datapack_collect data_acquire_pack; // 采集的数据包
Datapack_send data_send_pack; // 发送的数据包

//mode define
int work_mode = 0; //状态机用于判断切换当前状态（0-当前状态为WIFI-OTA阶段；1-当前状态为Bluetooth阶段）
int send_mode = 1; //发送数据模式(0-走串口可以接入外部数传；1-走蓝牙虚拟串口)

const char        *build_date = __DATE__;   // 11 characters MMM DD YYYY
const char        *build_time = __TIME__;   // 8 characters HH:MM:SS

/* ICM42605 Specify sensor parameters (sample rate is twice the bandwidth)
 * choices are:
      AFS_2G, AFS_4G, AFS_8G, AFS_16G  
      GFS_15_125DPS, GFS_31_25DPS, GFS_62_5DPS, GFS_125DPS, GFS_250DPS, GFS_500DPS, GFS_1000DPS, GFS_2000DPS 
      AODR_1_5625Hz, AODR_3_125Hz, AODR_6_25Hz, AODR_12_5Hz, AODR_25Hz, AODR_50Hz, AODR_100Hz, AODR_200Hz, AODR_500Hz, AODR_1000Hz, AODR_2000Hz, AODR_4000Hz, AODR_8000Hz
      GODR_12_5Hz, GODR_25Hz, GODR_50Hz, GODR_100Hz, GODR_200Hz, GODR_500Hz, GODR_1000Hz, GODR_2000Hz, GODR_4000Hz, GODR_8000Hz
*/ 
uint8_t ICM_Ascale = AFS_16G, ICM_Gscale = GFS_2000DPS, ICM_AODR = AODR_1000Hz, ICM_GODR = GODR_1000Hz; // 板载IMU量程速率配置，保持和外置IMU一致


/* QMI8658C Specify sensor parameters (sample rate is twice the bandwidth)
 * choices are:
      * AFS_2G, AFS_4G, AFS_8G, AFS_16G  
      * GFS_16DPS     , GFS_32DPS     , GFS_64DPS     , GFS_128DPS    , GFS_256DPS    , GFS_512DPS    , GFS_1024DPS   , GFS_2048DPS    
      * AODR_3Hz      , AODR_11Hz     , AODR_21Hz     , AODR_128Hz    , AODR_31_5Hz   , AODR_62_5Hz   , AODR_125Hz    , AODR_250Hz    , AODR_500Hz    , AODR_1000Hz   , AODR_2000Hz   , AODR_4000Hz   , AODR_8000Hz
      * GODR_31_5Hz   , GODR_62_5Hz   , GODR_125Hz    , GODR_250Hz    , GODR_500Hz    , GODR_1000Hz   , GODR_2000Hz   , GODR_4000Hz   , GODR_4000Hz, GODR_8000Hz   
*/ 
uint8_t QMI_Ascale = QMI_AFS_16G, QMI_Gscale = QMI_GFS_2048DPS, QMI_AODR = QMI_AODR_1000Hz, QMI_GODR = QMI_GODR_1000Hz;


float aRes, gRes;               // scale resolutions per LSB for the accel and gyro sensor2
float accelBias[3] = {0., 0., 0.}, gyroBias[3] = {0., 0., 0.}; // offset biases for the accel and gyro
int16_t IMU_Data[7];        // Stores the 16-bit signed sensor output

float Gtemperature;           // Stores the real internal gyro temperature in degrees Celsius
float ax, ay, az, gx, gy, gz;  // variables to hold latest accel/gyro data values 

float e_Gtemperature;           // Stores the real internal gyro temperature in degrees Celsius
float e_ax, e_ay, e_az, e_gx, e_gy, e_gz, e_mx, e_my, e_mz;  // variables to hold latest accel/gyro/mag data values 


// freertos 任务中MUTEX信号锁定义
SemaphoreHandle_t xMutex_datapack = NULL; //创建信号量Handler
TickType_t timeOut = 5; //用于获取信号量的Timeout 5 ticks

// //更新一次外置imu原始数据(9轴)
// void read_raw_exboard_imu_data(void);
//更新一次板载imu原始数据（6轴）
void read_raw_onboard_imu_data(void);
//电压采集
void ADC_read(void);
// UDP 发送函数
void UDP_send(void);
// 时间获取
void printLocalTime(void);
void getTime(int mode);

// freertos任务相关函数
void LED_Task(void *ptParam);
void Acquire_Task(void *ptParam);
void struct_deep_copy(Datapack *data_ac, Datapack *data_se);
void Send_Task(void *ptParam);
//Cal_Euler_angle_Task 任务主体
void Cal_Euler_angle_Task(void *ptPram);

// freertos任务创建
void freertos_task_create(void)
{
    xMutex_datapack = xSemaphoreCreateMutex(); //创建MUTEX
    xTaskCreatePinnedToCore(LED_Task, "LED_Blink", 1024 * 8, NULL, 1, NULL, 1);
    xTaskCreatePinnedToCore(Acquire_Task, "Datapack_Acquisition", 1024 * 8, NULL, 2, NULL, 1);
    vTaskDelay(1000); //让数据采集程序提前先运行一秒获取第一笔数据
    xTaskCreatePinnedToCore(Send_Task, "Datapack_Send", 1024 * 8, NULL, 2, NULL, 1);
    vTaskDelay(1000);
    xTaskCreatePinnedToCore(Cal_Euler_angle_Task, "Cal_Euler_angle", 1024*8,  NULL, 2, NULL, 1);
    Serial.println("Working on mode_1, has created 4 tasks[LED_Blink-2Hz, Datapack_Acquisition-125Hz, Datapack_Send-100Hz, Cal_Euler_angle-100Hz]");
}


void setup() {
  Serial.begin(115200);
  
  // Configure led
  pinMode(myLed_R, OUTPUT);
  digitalWrite(myLed_R, LOW); // start with led on
  pinMode(ad0, OUTPUT);
  digitalWrite(ad0, HIGH); //  set QMI8658C mode
  // pinMode(myLed_G, OUTPUT);
  // digitalWrite(myLed_G, LOW); // start with led on
  // pinMode(myLed_B, OUTPUT);
  // digitalWrite(myLed_B, LOW); // start with led on 
  delay(1000);
  
  // Connect to WiFi network
  Serial.println("WIFI start connecting...");
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.println("");

  // Wait for connection
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  // 连接wifi成功
  Serial.println("");
  Serial.print("Connected to ");
  Serial.println(ssid);
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
  digitalWrite(myLed_R, HIGH);
  delay(1000);
  digitalWrite(myLed_R, LOW);
  delay(1000);
  digitalWrite(myLed_R, HIGH);
  delay(1000);
  digitalWrite(myLed_R, LOW);
  delay(1000);
    
  // //基本外设初始化相关
  // pinMode(DC1, OUTPUT);
  // digitalWrite(DC1, LOW); // start with led on
  // pinMode(DC2, OUTPUT);
  // digitalWrite(DC2, LOW); // start with led on
  
  delay(100);

  Wire.begin(SDA0, SCL0); // set master mode 
  Wire.setClock(400000); // I2C frequency at 400 kHz  
  delay(1000);

  // 扫描挂接的IIC从机设备
  i2c_0.I2Cscan();

  // Read the ICM42605 Chip ID register, this is a good test of communication
  Serial.println("On board IMU--ICM42605 accel/gyro...");
  byte c = ICM42605.getChipID();  // Read CHIP_ID register for ICM42605
  Serial.print("On board IMU--ICM42605 "); Serial.print("I AM "); Serial.print(c, HEX); Serial.print(" I should be "); Serial.println(0x42, HEX);
  Serial.println(" ");
  delay(1000); 
  if(c == 0x42) // check if all I2C sensors have acknowledged
  {
    Serial.println("On board IMU--ICM42605 are online..."); Serial.println(" ");
    
    digitalWrite(myLed_R, HIGH);
    delay(1000);
    digitalWrite(myLed_R, LOW);
    ICM42605.reset();  // software reset ICM42605 to default registers

    // on board configuration get sensor resolutions, only need to do this once
    aRes = ICM42605.getAres(ICM_Ascale);
    gRes = ICM42605.getGres(ICM_Gscale);

    ICM42605.init(ICM_Ascale, ICM_Gscale, ICM_AODR, ICM_GODR);

    ICM42605.offsetBias(accelBias, gyroBias);
    Serial.println("On board IMU--accel biases (mg)"); Serial.println(1000.0f * accelBias[0]); Serial.println(1000.0f * accelBias[1]); Serial.println(1000.0f * accelBias[2]);
    Serial.println("On board IMU--gyro biases (dps)"); Serial.println(gyroBias[0]); Serial.println(gyroBias[1]); Serial.println(gyroBias[2]);
    delay(1000); 

    digitalWrite(myLed_R, HIGH);
    sensor_index = 1; //用于扫描IIC时候判定，0--unknown 1--ICM42605 2--QMI8658C
  }
  else 
  {
    if(c != 0x6A) Serial.println("On board IMU--ICM42605 not functioning!");
    sensor_index = 0; //用于扫描IIC时候判定，0--unknown 1--ICM42605 2--QMI8658C
  }

  if(sensor_index == 0) // 当且仅当没有识别到ICM42605加速度计才进入检测QMI8658C传感器
  {
    // Read the QMI8658C Chip ID register, this is a good test of communication
    Serial.println("On board IMU--QMI8658C accel/gyro...");
    byte c = QMI8658C.getChipID();  // Read CHIP_ID register for QMI8658C
    Serial.print("QMI8658C "); Serial.print("I AM "); Serial.print(c, HEX); Serial.print(" I should be "); Serial.println(0x05, HEX);
    Serial.println(" ");
    delay(1000); 
    if(c == 0x05) // check if all I2C sensors have acknowledged
    {
       Serial.println("On board IMU--QMI8658C are online..."); Serial.println(" ");
       
       digitalWrite(myLed_R, HIGH);
       delay(1000);
       digitalWrite(myLed_R, LOW);
    
       // get sensor resolutions, only need to do this once
       aRes = QMI8658C.getAres(QMI_Ascale);
       gRes = QMI8658C.getGres(QMI_Gscale);

       Serial.print("aRes*10000 = ");
       Serial.println(aRes*10000);
       Serial.print("gRes*10000 = ");
       Serial.println(gRes*10000);
    
       QMI8658C.init(QMI_Ascale, QMI_Gscale, QMI_AODR, QMI_GODR);
    
       QMI8658C.offsetBias(accelBias, gyroBias);
       Serial.println("accel biases (mg)"); Serial.println(1000.0f * accelBias[0]); Serial.println(1000.0f * accelBias[1]); Serial.println(1000.0f * accelBias[2]);
       Serial.println("gyro biases (dps)"); Serial.println(gyroBias[0]); Serial.println(gyroBias[1]); Serial.println(gyroBias[2]);
       delay(1000); 
    
       digitalWrite(myLed_R, HIGH);
       sensor_index = 2; //用于扫描IIC时候判定，0--unknown 1--ICM42605 2--QMI8658C
    }
    else 
    {
      if(c != 0x05) Serial.println(" QMI8658C not functioning!");
      sensor_index = 0; //用于扫描IIC时候判定，0--unknown 1--ICM42605 2--QMI8658C
      while(1){}; //不成功就阻塞
    }
  }

  // JY901.StartIIC(1);// 最后开启外置imu

  // 从网络时间服务器上获取并设置时间
  // 获取成功后芯片会使用RTC时钟保持时间的更新
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  printLocalTime();

  // 创建freertos任务
  freertos_task_create();
}
// End of setup //


void loop() {
  // all task has been transfered to freertos task !!! no need for loop();
}
// End of main loop //


/******************************  任务调度相关函数  **********************************/
//LED_Task 任务主体(兼容debug功能)
void LED_Task(void *ptParam) {  
  // 初始化当前tick时刻
  TickType_t xLastWakeTime = xTaskGetTickCount();
  // 定义单周期的tick数量
  const TickType_t xFrequency = 500; // 间隔 500 ticks = 0.5 seconds = 2Hz
  
  for(;;) //使用for更高效
  {
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
    // LED_Task 主任务
    led_status = !led_status;
    if(led_status==true)
    {
      digitalWrite(myLed_R, LOW); // start with led on
      // digitalWrite(myLed_G, HIGH); // start with led on
      // digitalWrite(myLed_B, LOW); // start with led on
    }
    else
    {
      digitalWrite(myLed_R, HIGH); // start with led on
      // digitalWrite(myLed_G, LOW); // start with led on
      // digitalWrite(myLed_B, HIGH); // start with led on
    }
    // 串口打印板载imu传感器信息-for debug
    if(SerialDebug == 1 && work_mode == 1) {
      Serial.println("On board imu data record:");
      Serial.print("ax = "); Serial.print((int)1000*ax);  
      Serial.print(" ay = "); Serial.print((int)1000*ay); 
      Serial.print(" az = "); Serial.print((int)1000*az); Serial.println(" mg");
      Serial.print("gx = "); Serial.print( gx, 2); 
      Serial.print(" gy = "); Serial.print( gy, 2); 
      Serial.print(" gz = "); Serial.print( gz, 2); Serial.println(" deg/s");
      Serial.print("Gyro temperature is ");  Serial.print(Gtemperature, 1);  Serial.println("° C"); // Print T values to tenths of s degree C

      Serial.println("Out of board imu data record:");
      Serial.print("e_ax = "); Serial.print((int)1000*e_ax);  
      Serial.print(" e_ay = "); Serial.print((int)1000*e_ay); 
      Serial.print(" e_az = "); Serial.print((int)1000*e_az); Serial.println(" mg");
      Serial.print("e_gx = "); Serial.print( e_gx, 2); 
      Serial.print(" e_gy = "); Serial.print( e_gy, 2); 
      Serial.print(" e_gz = "); Serial.print( e_gz, 2); Serial.println(" deg/s");
      Serial.print("e_mx = "); Serial.print( e_mx, 2); 
      Serial.print(" e_my = "); Serial.print( e_my, 2); 
      Serial.print(" e_mz = "); Serial.print( e_mz, 2); Serial.println("");
      Serial.print("e_temperature is ");  Serial.print(e_Gtemperature, 1);  Serial.println("° C"); // Print T values to tenths of s degree C
    }
  }
}


//Acquire_Task 任务主体
void Acquire_Task(void *ptParam) {  
  // 初始化当前tick时刻
  TickType_t xLastWakeTime = xTaskGetTickCount();
  // 定义单周期的tick数量
  const TickType_t xFrequency = 8; // 间隔 8 ticks = 8 ms = 125Hz
  
  for(;;) //使用for更高效
  {
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
    
    // 首先查询datapack的Mutex锁是否被占用
    if (xSemaphoreTake(xMutex_datapack, timeOut) == pdPASS) { // 未被占用
      
      // Acquire_Task 主任务
      read_raw_onboard_imu_data(); // 板载imu数据获取
      // read_raw_exboard_imu_data(); // 外置imu数据获取
      // ADC_read(); // adc数据获取
      getTime(time_from);// 时间获取
      
      xSemaphoreGive(xMutex_datapack); //释放钥匙
    }
    else{
      // 发现被占用 do nothing
    }
  }
}


//结构体深度拷贝(√)
void struct_deep_copy(Datapack_collect *data_ac, Datapack_send *data_se)
{
  int i = 0;
  for(i = 0;i < 3;i++)
  {
    data_se->data_imu_onboard[i] = 1000 * data_ac->data_imu_onboard[i];
  }
  for( ;i < 6;i++)
  {
    data_se->data_imu_onboard[i] = 100 * data_ac->data_imu_onboard[i];
  }
  if(time_from == 1) // 从网络时间来
  {
    for(i = 0;i < 4;i++)
    {
      data_se->time_record[i] = data_ac->time_record[i];
    }
  }
  else if(time_from == 2) // 从系统时钟来
  {
    data_se->time_sys = data_ac->time_sys;
  }
}



//Cal_Euler_angle_Task 任务主体
void Cal_Euler_angle_Task(void *ptPram)
{
  // 初始化当前tick时刻
  TickType_t xLastWakeTime = xTaskGetTickCount();
  // 定义单周期的tick数量
  const TickType_t xFrequency = 10; // 间隔 10 ticks = 10 ms = 100Hz
  
  for(;;) //使用for更高效
  {
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
    // 首先查询datapack的Mutex锁是否被占用
    if (xSemaphoreTake(xMutex_datapack, timeOut) == pdPASS) { // 未被占用
      
      // Cal_Euler_angle_Task 主任务 这里主任务必须尽量轻不要占用过多时间！！！(遵守先把数据提取出来，然后立刻释放，数据再处理)
      o_ax = data_acquire_pack.data_imu_onboard[0] * 9.8f;
      o_ay = data_acquire_pack.data_imu_onboard[1] * 9.8f;
      o_az = data_acquire_pack.data_imu_onboard[2] * 9.8f;
      o_gx = data_acquire_pack.data_imu_onboard[3];
      o_gy = data_acquire_pack.data_imu_onboard[4];
      o_gz = data_acquire_pack.data_imu_onboard[5];    
      xSemaphoreGive(xMutex_datapack); //释放钥匙
    }
    else{
      // 发现被占用 do nothing
    }

    deltat = fusion.deltatUpdate(); //this have to be done before calling the fusion update
    //choose only one of these two:
    fusion.MahonyUpdate(o_gx, o_gy, o_gz, o_ax, o_ay, o_az, deltat);  //mahony is suggested if there isn't the mag and the mcu is slow
    // fusion.MadgwickUpdate(o_gx, o_gy, o_gz, o_ax, o_ay, o_az, o_mx, o_my, o_mz, deltat);  //else use the magwick, it is slower but more accurate
    pitch = fusion.getPitch();
    roll = fusion.getRoll();
    yaw = fusion.getYaw();

    cal_q[0] = fusion.getQuat()[0];
    cal_q[1] = fusion.getQuat()[1];
    cal_q[2] = fusion.getQuat()[2];
    cal_q[3] = fusion.getQuat()[3];

    data_send_pack.onboard_euler_angle[0] = int16_t(roll * 100.0f);
    data_send_pack.onboard_euler_angle[1] = int16_t(pitch * 100.0f);
    data_send_pack.onboard_euler_angle[2] = int16_t(yaw * 100.0f);
    data_send_pack.onboard_qu_value[0] = int16_t(cal_q[0] * 10000.0f);
    data_send_pack.onboard_qu_value[1] = int16_t(cal_q[1] * 10000.0f);
    data_send_pack.onboard_qu_value[2] = int16_t(cal_q[2] * 10000.0f);
    data_send_pack.onboard_qu_value[3] = int16_t(cal_q[3] * 10000.0f);

    pitch = fusion.getPitchRadians();
    roll = fusion.getRollRadians();
    yaw = fusion.getYawRadians();

    if(send_mode == 0) // 注意这里逻辑和send_task相反，send_task发蓝牙这边就发串口，send_task发串口这边就发蓝牙
    {
      Serial.print(pitch); 
      Serial.print(":");
      Serial.print(roll); 
      Serial.print(":");
      Serial.println(yaw);
    }
  }
}



//Send_Task 任务主体
void Send_Task(void *ptParam) {  
  // 初始化当前tick时刻
  TickType_t xLastWakeTime = xTaskGetTickCount();
  // 定义单周期的tick数量
  const TickType_t xFrequency = 10; // 间隔 10 ticks = 10 ms = 100Hz
  
  for(;;) //使用for更高效
  {
    vTaskDelayUntil(&xLastWakeTime, xFrequency);
    // 首先查询datapack的Mutex锁是否被占用
    if (xSemaphoreTake(xMutex_datapack, timeOut) == pdPASS) { // 未被占用
      
      // Send_Task 主任务 这里主任务必须尽量轻不要占用过多时间！！！(遵守先把数据提取出来，然后立刻释放，数据再发送出去)
      // struct_shallow_copy();// 浅拷贝数据会出问题，因为存在数组传递的只是地址不是具体的数值！！！
      struct_deep_copy(&data_acquire_pack, &data_send_pack);
      xSemaphoreGive(xMutex_datapack); //释放钥匙
    }
    else{
      // 发现被占用 do nothing
    }
    // 发送单独放出来，不过多占用MUTEX时间
    UDP_send();
  }
}
/******************************  任务调度相关函数  **********************************/


// /******************************  数据采集相关函数  **********************************/
// //更新一次外置imu原始数据(9轴)
// void read_raw_exboard_imu_data(void)
// {
//   // 读取imu原始数据
//   JY901.GetAcc();
//   JY901.GetGyro();  
//   JY901.GetMag();
//   JY901.GetTemp();
  
//   // Now we'll calculate the accleration value into actual g's
//   e_ax = (float)JY901.stcAcc.a[0]/32768*16;  // get actual g value, this depends on scale being set
//   e_ay = (float)JY901.stcAcc.a[1]/32768*16;   
//   e_az = (float)JY901.stcAcc.a[2]/32768*16;  
//   // Calculate the gyro value into actual degrees per second
//   e_gx = (float)JY901.stcGyro.w[0]/32768*2000;  // get actual gyro value, this depends on scale being set
//   e_gy = (float)JY901.stcGyro.w[1]/32768*2000;  
//   e_gz = (float)JY901.stcGyro.w[2]/32768*2000;
//   // mag data
//   e_mx = (float)JY901.stcMag.h[0]*1.0;  // get actual gyro value, this depends on scale being set
//   e_my = (float)JY901.stcMag.h[1]*1.0;  
//   e_mz = (float)JY901.stcMag.h[2]*1.0; 
//   // temp 
//   e_Gtemperature = (float)JY901.Temp; // /100.0 Gyro chip temperature in degrees Centigrade
  
//   //加速度计
//   data_acquire_pack.data_imu_exboard[0] = (int)1000*e_ax;  // get actual g value, this depends on scale being set
//   data_acquire_pack.data_imu_exboard[1] = (int)1000*e_ay;   
//   data_acquire_pack.data_imu_exboard[2] = (int)1000*e_az;

//   //陀螺仪
//   data_acquire_pack.data_imu_exboard[3] = (int)10*e_gx;  // get actual gyro value, this depends on scale being set
//   data_acquire_pack.data_imu_exboard[4] = (int)10*e_gy;   
//   data_acquire_pack.data_imu_exboard[5] = (int)10*e_gz;

//   //磁力计
//   data_acquire_pack.data_imu_exboard[6] = (int)100*e_mx;  // get actual mag value, this depends on scale being set
//   data_acquire_pack.data_imu_exboard[7] = (int)100*e_my;   
//   data_acquire_pack.data_imu_exboard[8] = (int)100*e_mz;

//   //温度
//   data_acquire_pack.data_imu_exboard[9] = (int)e_Gtemperature;
// }


//更新一次板载imu原始数据（6轴）
void read_raw_onboard_imu_data(void)
{
  if(sensor_index==1)
  {
    // 读取ICM的IMU原始数据
    ICM42605.readData(IMU_Data);  
  }
  else if(sensor_index==2)
  {
    // 读取imu原始数据
    QMI8658C.readData(IMU_Data); 
  }

  // ax = (float)IMU_Data[1]*aRes;  //  - accelBias[0] get actual g value, this depends on scale being set
  // ay = (float)IMU_Data[2]*aRes;  //  - accelBias[1]
  // az = (float)IMU_Data[3]*aRes;  //  - accelBias[2]
  ax = (float)IMU_Data[1]*aRes - accelBias[0];  //   get actual g value, this depends on scale being set
  ay = (float)IMU_Data[2]*aRes - accelBias[1];  //
  az = (float)IMU_Data[3]*aRes - accelBias[2];  // 

  // Calculate the gyro value into actual degrees per second
  gx = (float)IMU_Data[4]*gRes - gyroBias[0];  // get actual gyro value, this depends on scale being set
  gy = (float)IMU_Data[5]*gRes - gyroBias[1];  
  gz = (float)IMU_Data[6]*gRes - gyroBias[2];
  // temp 
  Gtemperature = ((float) IMU_Data[0]) / 256.0f * 100; // Gyro chip temperature in degrees Centigrade
  
  //加速度计
  data_acquire_pack.data_imu_onboard[0] = ax;  // (int)1000* get actual g value, this depends on scale being set
  data_acquire_pack.data_imu_onboard[1] = ay;  // (int)1000*
  data_acquire_pack.data_imu_onboard[2] = az;  // (int)1000*

  //陀螺仪 转为弧度制
  data_acquire_pack.data_imu_onboard[3] = gx/180*pi;  // (int) get actual gyro value, this depends on scale being set
  data_acquire_pack.data_imu_onboard[4] = gy/180*pi;  // (int)
  data_acquire_pack.data_imu_onboard[5] = gz/180*pi;  // (int)

  //温度
  data_acquire_pack.data_imu_onboard[6] = Gtemperature;
   
}


// //电压采集
// void ADC_read(void)
// {
//     data_acquire_pack.data_adc[0] = analogRead(potPin_01);  
//     data_acquire_pack.data_adc[1] = analogRead(potPin_02);  
//     data_acquire_pack.data_adc[2] = analogRead(potPin_03);  
//     data_acquire_pack.data_adc[3] = analogRead(potPin_04);  
//     data_acquire_pack.data_adc[4] = analogRead(potPin_05);  
// }

// 网络时间
void printLocalTime(void)
{
    struct tm timeinfo;
    while (!getLocalTime(&timeinfo))
    {
        Serial.println("Failed to obtain time");
        delay(100);
    }
    Serial.println(&timeinfo, "%F %T %A"); // 格式化输出
}

// 网络时间/系统ms时间切换
void getTime(int mode)
{
  if(mode == 1) // 网络时间模式（精确到s）
  {
    struct tm timeinfo;
    if (!getLocalTime(&timeinfo))
    {
      Serial.println("Failed to obtain time");
      return;
    }
    data_acquire_pack.time_record[0] = timeinfo.tm_sec;
    data_acquire_pack.time_record[1] = timeinfo.tm_min;
    data_acquire_pack.time_record[2] = timeinfo.tm_hour;
    data_acquire_pack.time_record[3] = timeinfo.tm_mday;
  }
  else if(mode == 2) // 系统时间模式 (精确到ms)
  {
    data_acquire_pack.time_sys = millis();
  }
}
/******************************  数据采集相关函数  **********************************/


/******************************  数据发送相关函数  **********************************/
// UDP Broadcast slider values
void UDP_send(void) {
  String builtString = String("");
  static int package_index = 0;

  // 包index (用于统计丢包情况的)
  builtString += String((int)package_index++);
  builtString += String("|");
  
  if(time_from == 1)
  {
    // 时间数据 [TM_sec | TM_min | TM_hour]
    for (int i = 0; i < 3; i++) {
      builtString += String((int)data_send_pack.time_record[i]);
      // Build the string to broadcast by seperating values using | except for last value
      builtString += String("|");
    }
  }
  else if(time_from == 2)
  {
    builtString += String((int)data_send_pack.time_sys);
    // Build the string to broadcast by seperating values using | except for last value
    builtString += String("|");
  }

  // // 电压数据 [TENG1 | TENG2 | RES1 | RES2 | BATTERY]
  // for (int i = 0; i < 5; i++) {
  //   builtString += String((int)data_send_pack.data_adc[i]);
  //   // Build the string to broadcast by seperating values using | except for last value
  //   builtString += String("|");
  // }

  // 板载IMU原始数据 [1000*ax | 1000*ay | 1000*az | 100*gx | 100*gy | 100*gz | 100*Gtemperature]
  for (int i = 0; i < 7; i++) {
    builtString += String((int)data_send_pack.data_imu_onboard[i]);
    // Build the string to broadcast by seperating values using | except for last value
      builtString += String("|");
  }

  // 板载IMU融合后数据 [100*pitch | 100*roll | 100*yaw]
  for (int i = 0; i < 3; i++) {
    builtString += String((int)data_send_pack.onboard_euler_angle[i]);
    // Build the string to broadcast by seperating values using | except for last value
    if (i < 3 - 1) {
      builtString += String("|");
    }
  }

  // // 外置IMU数据 [1000*e_ax | 1000*e_ay | 1000*e_az | 10*e_gx | 10*e_gy | 10*e_gz | 100*e_mx | 100*e_my | 100*e_mz | e_Gtemperature]
  // for (int i = 0; i < 10; i++) {
  //   builtString += String((int)data_send_pack.data_imu_exboard[i]);
  //   // Build the string to broadcast by seperating values using | except for last value
  //   if (i < 10 - 1) {
  //     builtString += String("|");
  //   }
  // }


  // 广播给每个ip, 端口号2255(存在丢包)
  udp.broadcastTo(builtString.c_str(), 3355);

  // 发给指定ip, 端口号2255 有问题未解决（发送给制定端口）
  // udp.writeTo(builtString.c_str(), 111, To_IP, 2255);  //准备发送数据到目标IP和目标端口
}
/******************************  数据发送相关函数  **********************************/
